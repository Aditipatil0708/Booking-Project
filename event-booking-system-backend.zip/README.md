# Event Booking System – Backend

## Tech Stack
- Java 17
- Spring Boot
- MongoDB

## Features
- Event browsing
- Admin event creation
- Ticket booking with availability checks

## Setup
1. Install Java 17 & MongoDB
2. Run:
   mvn spring-boot:run
