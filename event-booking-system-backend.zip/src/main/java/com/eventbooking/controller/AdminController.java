package com.eventbooking.controller;

import com.eventbooking.model.Event;
import com.eventbooking.service.EventService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    private final EventService service;

    public AdminController(EventService service) {
        this.service = service;
    }

    @PostMapping("/event")
    public Event create(@RequestBody Event event) {
        return service.save(event);
    }
}
