package com.eventbooking.service;

import com.eventbooking.model.Event;
import com.eventbooking.repository.EventRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class EventService {
    private final EventRepository repo;

    public EventService(EventRepository repo) {
        this.repo = repo;
    }

    public List<Event> getAllEvents() {
        return repo.findAll();
    }

    public Event save(Event event) {
        return repo.save(event);
    }
}
